<!DOCTYPE html>
<html>
<meta charset = "utf-8">

<head>
    <title> pageTwo </title>
</head>
<body style="background-color: #DCDCDC">

</body>
</html>

<?php

$servername = "localhost";
$username = "roba";
$password = "1234";
$db = "Robot_control";

$conn = new mysqli($servername, $username, $password, $db);

if ($conn->connect_error) {
  die("Connection failed: " . $conn->connect_error);
}
echo "Connected successfully";


if (isset($_POST['forwards'])){
  echo "<p>F</p>";
$insert = "INSERT INTO control (F, L, S, R, B) VALUES (1, 0, 0, 0, 0)";
mysqli_query($conn,$insert);
}


if (isset($_POST['left'])){
  echo "<p>L</p>";
  $insert = "INSERT INTO control (F, L, S, R, B) VALUES (0, 1, 0, 0, 0)";
  mysqli_query($conn,$insert);
}

if (isset($_POST['stop'])){
  echo "<p>S</p>";
  $insert = "INSERT INTO control (F, L, S, R, B) VALUES (0, 0, 1, 0, 0)";
  mysqli_query($conn,$insert);
}

if (isset($_POST['right'])){
  echo "<p>R</p>";
  $insert = "INSERT INTO control (F, L, S, R, B) VALUES (0, 0, 0, 1, 0)";
  mysqli_query($conn,$insert);
}

if(isset($_POST['backwards'])){
  echo "<p>B</p>";
  $insert = "INSERT INTO control (F, L, S, R, B) VALUES (0, 0, 0, 0, 1)";
  mysqli_query($conn,$insert);
}


mysqli_close($conn);


?>
